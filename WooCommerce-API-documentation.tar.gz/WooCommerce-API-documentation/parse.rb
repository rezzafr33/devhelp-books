#!/usr/bin/env/ ruby

require 'nokogiri'

start = Nokogiri::HTML(open("index.html"))

File.open("WooCommerce-API-documentation.devhelp2", "w") do |f|
	f.puts "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
	f.puts "<book xmlns=\"http://www.devhelp.net/book\" title=\"WooCommerce\" language=\"php\" name=\"woocommerce\" author=\"\" link=\"index.html\">"
	f.puts "\t<chapters>"

	#packages
	title = start.css('#groups h3')[0].text
	links = start.css('#groups ul li > a')
	f.puts "\t\t<sub name=\"#{title}\" link=\"index.html\">"
	links.each{|link|
		f.puts "\t\t\t<sub name=\"#{link.text}\" link=\"#{link['href']}\"/>"
	}
	f.puts "\t\t</sub>"


	#classes
	links = start.css('#elements ul')[0].css('li > a')
	f.puts "\t\t<sub name=\"Classes\" link=\"package-WooCommerce.Classes.html\">"
	links.each{|link|
		f.puts "\t\t\t<sub name=\"#{link.text}\" link=\"#{link['href']}\"/>"
	}
	f.puts "\t\t</sub>"

	#exceptions
	links = start.css('#elements ul')[1].css('li > a')
	f.puts "\t\t<sub name=\"Exceptions\" link=\"class-Exception.html\">"
	links.each{|link|
		f.puts "\t\t\t<sub name=\"#{link.text}\" link=\"#{link['href']}\"/>"
	}
	f.puts "\t\t</sub>"

	#functions
	links = start.css('#elements ul')[2].css('li > a')
	f.puts "\t\t<sub name=\"Functions\" link=\"package-WooCommerce.Functions.html\">"
	links.each{|link|
		f.puts "\t\t\t<sub name=\"#{link.text}\" link=\"#{link['href']}\"/>"
	}
	f.puts "\t\t</sub>"

	f.puts "\t</chapters>"
	f.puts "</book>"
end
