jQuery(document).ready(function($) {


    // prettyprint
    $('pre').addClass('prettyprint');

	// uniform
	$('select, input:checkbox, input:radio, input:file').uniform();

});
