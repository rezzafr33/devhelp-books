#!/usr/bin/env/ ruby

require 'nokogiri'

start = Nokogiri::HTML(open("getting-started.1.html"))
components = Nokogiri::HTML(open("components.1.html"))
css = Nokogiri::HTML(open("css/index.html"))
javascript = Nokogiri::HTML(open("javascript/index.html"))

# links = components.css('.nav.bs-docs-sidenav li a')
# File.open("components.csv", "w") do |f|
# 	f.puts "<sub name=\"components\" link=\"components.1.html\">"
# 	links.each{|link|
# 		f.puts "\t<sub name=\"#{link.text}\" link=\"#{link['href']}\""
# 	}
# 	f.puts "</sub>"
# end

# links = css.css('.nav.bs-docs-sidenav li a')
# File.open("css.csv", "w") do |f|
# 	f.puts "<sub name=\"css\" link=\"css/index.html\">"
# 	links.each{|link|
# 		f.puts "\t<sub name=\"#{link.text}\" link=\"#{link['href']}\""
# 	}
# 	f.puts "</sub>"
# end

# links = javascript.css('.nav.bs-docs-sidenav li a')
# File.open("javascript.csv", "w") do |f|
# 	f.puts "<sub name=\"javascript\" link=\"javascript/index.html\">"
# 	links.each{|link|
# 		f.puts "\t<sub name=\"#{link.text}\" link=\"#{link['href']}\""
# 	}
# 	f.puts "</sub>"
# end

File.open("getbootstrap.com.devhelp2", "w") do |f|
	f.puts "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
	f.puts "<book xmlns=\"http://www.devhelp.net/book\" title=\"Bootstrap\" language=\"html\" name=\"bootstrap\" version=\"3.2.0\" author=\"\" link=\"index.html\">"
	f.puts "\t<chapters>"

	links = start.css('.nav.bs-docs-sidenav li a')
	f.puts "\t\t<sub name=\"getting-started\" link=\"getting-started.1.html\">"
	links.each{|link|
		f.puts "\t\t\t<sub name=\"#{link.text}\" link=\"#{link['href']}\"/>"
	}
	f.puts "\t\t</sub>"

	# css
	links = css.css('.nav.bs-docs-sidenav li a')
	f.puts "\t\t<sub name=\"css\" link=\"css/index.html\">"
	links.each{|link|
		f.puts "\t\t\t<sub name=\"#{link.text}\" link=\"css/#{link['href']}\"/>"
	}
	f.puts "\t\t</sub>"

	# components
	links = components.css('.nav.bs-docs-sidenav li a')
	f.puts "\t\t<sub name=\"components\" link=\"components.1.html\">"
	links.each{|link|
		f.puts "\t\t\t<sub name=\"#{link.text}\" link=\"#{link['href']}\"/>"
	}
	f.puts "\t\t</sub>"

	# javascript
	links = javascript.css('.nav.bs-docs-sidenav li a')
	f.puts "\t\t<sub name=\"javascript\" link=\"javascript/index.html\">"
	links.each{|link|
		f.puts "\t\t\t<sub name=\"#{link.text}\" link=\"javascript/#{link['href']}\"/>"
	}
	f.puts "\t\t</sub>"

	f.puts "\t</chapters>"
	f.puts "</book>"
end